package kr.ac.dankook.dantumproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ChoiceThree : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choice_three)
    }
}