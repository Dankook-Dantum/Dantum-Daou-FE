package kr.ac.dankook.dantumproject.issue

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_issuemain.*
import kr.ac.dankook.dantumproject.R
import kr.ac.dankook.dantumproject.RestApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class IssueMain : AppCompatActivity() {
    var Userlist = arrayListOf<Issues>(
        Issues("Issue", "[투표 결과 조회]", "투표 결과 확인이 안 됨", "노근우"),
        Issues("In Progress", "[상세 프로필 조회]", "상세 프로필 잘림", "김수연"),
        Issues("Done", "이슈제목", "이슈내용", "작성자"),
        Issues("0", "이슈제목", "이슈내용", "작성자")
    )

    override fun onCreate(savedInstanceState: Bundle?) { // 액티비티의 실행 시작 지점
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_issuemain)

        //val item = arrayOf("사과", "배", "딸기", "키위", "HOXY")
        //listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, item)
        val Adapter = IssuesAdapter(this, Userlist)
        listView.adapter = Adapter

    }
}