package kr.ac.dankook.dantumproject.issue

class Issues (val lable: String, val issuetitle: String, val issuecontents: String, val issuewriter: String)