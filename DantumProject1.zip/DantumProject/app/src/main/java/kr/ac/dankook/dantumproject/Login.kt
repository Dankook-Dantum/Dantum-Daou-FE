package kr.ac.dankook.dantumproject

data class Login(
    var email: String = "",

    var password: String = "",
)
